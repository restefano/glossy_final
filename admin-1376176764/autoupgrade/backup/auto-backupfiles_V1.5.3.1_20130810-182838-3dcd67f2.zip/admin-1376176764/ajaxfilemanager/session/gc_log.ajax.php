<?php die(); ?>
gc start at 14/Sep/2010 17:35:57
